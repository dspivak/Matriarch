# -*- coding: utf-8 -*-
"""
Created on Mon Apr 13 10:21:53 2015

@author: Tristan Giesa, David I. Spivak, Ravi Jagadeesan
"""

import matriarchmySeq = 'AAAPPY'myChain = matriarch.chain(mySeq)print(myChain)myChain.fileOut('03-myChain.pdb')