All amino acid sources from http://wbiomed.curtin.edu.au/biochem/tutorials/pdb/.
Then, processed through AutoPSF.